package com.autos.empresaseguros;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmpresaSegurosApplicationTests {

    @Test
    void contextLoads() {
    }

}
