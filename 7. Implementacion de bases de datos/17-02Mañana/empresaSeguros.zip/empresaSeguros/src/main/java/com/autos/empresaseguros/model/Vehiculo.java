package com.autos.empresaseguros.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;
import lombok.Getter;

@Entity
@Data
@Table(name = "vehiculo")
public class Vehiculo {
    @Id
    private Long id;
    private String patente;
    private String marca;
    private String modelo;
    @Column(name = "anio_fabricacion")
    private int anioFabricacion;
    @Column(name = "cantidad_ruedas")
    private int cantidadRuedas;
}
