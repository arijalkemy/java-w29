package hql.hqlmovies.service;

import hql.hqlmovies.dto.ActorDTO;
import hql.hqlmovies.repository.IActorRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ActorServiceImpl implements IActorService {

    private final IActorRepository actorRepository;

    public ActorServiceImpl(IActorRepository actorRepository) {
        this.actorRepository = actorRepository;
    }

    @Override
    public List<ActorDTO> getAllActorsWithFavoriteMovies() {
        return actorRepository.findActorsWithFavoriteMovie().stream()
                .map(actor -> ActorDTO.builder()
                        .firstName(actor.getFirstName())
                        .lastName(actor.getLastName())
                        .favoriteMovieTitle(actor.getFavoriteMovie().getTitle())
                        .build())
                .collect(Collectors.toList());
    }

    public List<ActorDTO> getActorsWithRatingAbove(Double rating) {
        return actorRepository.findActorsWithRatingAbove(rating).stream()
                .map(actor -> ActorDTO.builder()
                        .firstName(actor.getFirstName())
                        .lastName(actor.getLastName())
                        .rating(actor.getRating())
                        .build())
                .collect(Collectors.toList());
    }
}
