package hql.hqlmovies.service;

import hql.hqlmovies.dto.ActorDTO;
import hql.hqlmovies.dto.MovieDTO;

import java.util.List;

public interface IMovieService {
    List<MovieDTO> getAllMovies();
}
