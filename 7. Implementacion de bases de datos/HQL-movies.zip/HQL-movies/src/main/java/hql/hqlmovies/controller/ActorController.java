package hql.hqlmovies.controller;

import hql.hqlmovies.dto.ActorDTO;
import hql.hqlmovies.service.ActorServiceImpl;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/actors")
public class ActorController {
    private final ActorServiceImpl actorService;

    public ActorController(ActorServiceImpl actorService) {
        this.actorService = actorService;
    }

    @GetMapping("/with-favorite-movie")
    public ResponseEntity<List<ActorDTO>> getActorsWithFavoriteMovie() {
        return ResponseEntity.ok(actorService.getAllActorsWithFavoriteMovies());
    }

    @GetMapping("/with-rating-above/{rating}")
    public ResponseEntity<List<ActorDTO>> getActorsWithRatingAbove(@PathVariable Double rating) {
        return ResponseEntity.ok(actorService.getActorsWithRatingAbove(rating));
    }
}