package hql.hqlmovies.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import hql.hqlmovies.dto.ActorDTO;
import hql.hqlmovies.dto.MovieDTO;
import hql.hqlmovies.repository.IMovieRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class MovieServiceImpl implements IMovieService {

    private final IMovieRepository movieRepository;

    public MovieServiceImpl(IMovieRepository movieRepository, ObjectMapper objectMapper) {
        this.movieRepository = movieRepository;
    }

    @Override
    public List<MovieDTO> getAllMovies() {

        return movieRepository.findAll().stream()
                .map(movie -> new MovieDTO(movie.getTitle(), movie.getRating()))
                .collect(Collectors.toList());
    }
}