package hql.hqlmovies;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HqlMoviesApplication {

    public static void main(String[] args) {
        SpringApplication.run(HqlMoviesApplication.class, args);
    }

}
