package hql.hqlmovies.service;

import hql.hqlmovies.dto.ActorDTO;

import java.util.List;

public interface IActorService {
    List<ActorDTO> getAllActorsWithFavoriteMovies();
}