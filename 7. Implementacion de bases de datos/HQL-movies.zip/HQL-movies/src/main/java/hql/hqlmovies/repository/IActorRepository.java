package hql.hqlmovies.repository;

import hql.hqlmovies.model.Actor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IActorRepository extends JpaRepository<Actor, Integer> {
    @Query("SELECT a FROM Actor a JOIN FETCH a.favoriteMovie m WHERE a.favoriteMovie IS NOT NULL")
    List<Actor> findActorsWithFavoriteMovie();

    @Query("SELECT a FROM Actor a WHERE a.rating > :rating")
    List<Actor> findActorsWithRatingAbove(@Param("rating") Double rating);

}