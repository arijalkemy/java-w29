package jpa.miniserie.service;

import jpa.miniserie.model.Jewel;
import jpa.miniserie.repository.IJoyaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class JoyaService implements IJoyaService {

    @Autowired
    IJoyaRepository jewelRepo;

    @Override
    public String saveJewel(Jewel jewel) {
        this.jewelRepo.save(jewel);
        return "saved with id: " + jewel.getId();
    }

    @Override
    public List<Jewel> getJewel() {

        return jewelRepo.findAll()
                .stream()
                .filter(Jewel::isVentaONo)
                .collect(Collectors.toList());
    }

    @Override
    public Jewel findJewel(Long id) {
        return jewelRepo.findById(id).orElse(null);
    }

    @Override
    public String deleteJewel(Long id) {

        Jewel jewelOriginal = this.findJewel(id);
        jewelOriginal.setVentaONo(false);
        this.saveJewel(jewelOriginal);

        return "Deleted";
    }

    @Override
    public String editJewel(Long id_modificar, Jewel jewel_edited) {

        Jewel jewelOriginal = this.findJewel(id_modificar);

        jewelOriginal.setNombre(jewel_edited.getNombre());
        jewelOriginal.setMaterial(jewel_edited.getMaterial());
        jewelOriginal.setPeso(jewel_edited.getPeso());
        jewelOriginal.setParticularidad(jewel_edited.getParticularidad());
        jewelOriginal.setPosee_piedra(jewel_edited.isPosee_piedra());
        jewelOriginal.setVentaONo(jewel_edited.isVentaONo());

        this.saveJewel(jewelOriginal);
        return "Updated";

    }
}
