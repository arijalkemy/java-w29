package jpa.miniserie.service;

import jpa.miniserie.model.Jewel;

import java.util.List;

public interface IJoyaService {

    public String saveJewel(Jewel jewel);
    public List<Jewel> getJewel();
    public Jewel findJewel(Long id);
    public String deleteJewel(Long id);
    public String editJewel(Long id_modificar, Jewel jewel_edited);


}
