package jpa.miniserie.repository;

import jpa.miniserie.model.Jewel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface IJoyaRepository extends JpaRepository<Jewel, Long> {



}
