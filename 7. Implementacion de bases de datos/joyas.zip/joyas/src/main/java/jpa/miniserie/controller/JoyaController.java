package jpa.miniserie.controller;

import jpa.miniserie.model.Jewel;
import jpa.miniserie.service.IJoyaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class JoyaController {

    @Autowired
    IJoyaService jewelService;

    @PostMapping("/jewerly/new")
    public String saveJewel (@RequestBody Jewel jewel) {
        return jewelService.saveJewel(jewel);
    }

    @GetMapping("/jewerly")
    public List<Jewel> getJewelry () {
        return jewelService.getJewel();
    }

    @PutMapping("/jewerly/delete/{id}")
    public String deleteJewel (@PathVariable Long id) {
        return jewelService.deleteJewel(id);
    }

    @PutMapping ("/jewerly/update/{id}")
    public String editJewel (@PathVariable Long id,
                            @RequestBody Jewel jewel) {
        return jewelService.editJewel(id, jewel);
    }



}

