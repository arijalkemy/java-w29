package com.meli.blog.service;

import com.meli.blog.dto.BlogDto;

import java.util.List;
import java.util.Optional;

public interface IBlogService {
    Optional<BlogDto> getById(Integer id);
    Optional<BlogDto> save(BlogDto blog);
    List<BlogDto> getAll();
}
